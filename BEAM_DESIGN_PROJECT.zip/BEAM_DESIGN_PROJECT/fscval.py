import numpy as np
def fscvalue(d,dc,fy):
    b=dc/d;
    a=np.loadtxt('fscvalues.txt');
    dratio=np.transpose(a[:,0])
    r1=np.transpose(a[:,1])
    r2=np.transpose(a[:,2])
    if (fy == 250):
        fsc=0.87*fy;
    elif(fy == 415):
        for k in range(1):#1:1
            if((b>=dratio[k]) and (b<dratio[k+1])):
                fsc=r1[k]+(((r1[k+1]-r1[k])*(b-dratio[k]))/((dratio[k+1]-dratio[k])));
                break
            elif((b>=dratio[k+1]) and (b<dratio[k+2])):
                    fsc=r1[k+1]+(((r1[k+2]-r1[k+1])*(b-dratio[k+1]))/((dratio[k+2]-dratio[k+1])));
                    break
            elif((b>=dratio[k+2]) and (b<=dratio[k+3])):
                    fsc=r1[k+2]+(((r1[k+3]-r1[k+2])*(b-dratio[k+2]))/((dratio[k+3]-dratio[k+2])));
                    break     
                #end
            #end
    elif(fy == 500):
        for k in range(1):#=1:1
            if((b>=dratio[k]) and (b<dratio[k+1])):
                fsc=r2[k]+(((r2[k+1]-r2[k])*(b-dratio[k]))/((dratio[k+1]-dratio[k])))
                break
            elif((b>=dratio[k+1]) and (b<dratio[k+2])):
                fsc=r2[k+1]+(((r2[k+2]-r2[k+1])*(b-dratio[k+1]))/((dratio[k+2]-dratio[k+1])))
                break
            elif((b>=dratio[k+2]) and (b<=dratio[k+3])):
                fsc=r2[k+2]+(((r2[k+3]-r2[k+2])*(b-dratio[k+2]))/((dratio[k+3]-dratio[k+2])))
                break     
               # end
    return(fsc)
#fsc=fscvalue(d,dc,fy)
#print(fsc)