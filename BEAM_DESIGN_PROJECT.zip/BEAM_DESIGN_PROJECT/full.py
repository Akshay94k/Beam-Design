import math as m
import numpy as np
import scipy as sp

def fscvalue(d,dc,fy):
    b=dc/d;
    a=np.loadtxt('fscvalues.txt');
    dratio=sp.transpose(a[:,0])
    r1=np.transpose(a[:,1])
    r2=np.transpose(a[:,2])
    if (fy == 250):
        fsc=0.87*fy
    elif(fy == 415):
        for k in range(1):#1:1
            if((b>=dratio[k]) and (b<dratio[k+1])):
                fsc=r1[k]+(((r1[k+1]-r1[k])*(b-dratio[k]))/((dratio[k+1]-dratio[k])));
                break
            elif((b>=dratio[k+1]) and (b<dratio[k+2])):
                    fsc=r1[k+1]+(((r1[k+2]-r1[k+1])*(b-dratio[k+1]))/((dratio[k+2]-dratio[k+1])));
                    break
            elif((b>=dratio[k+2]) and (b<=dratio[k+3])):
                    fsc=r1[k+2]+(((r1[k+3]-r1[k+2])*(b-dratio[k+2]))/((dratio[k+3]-dratio[k+2])));
                    break     
                #end
            #end
    elif(fy == 500):
        for k in range(1):#=1:1
            if((b>=dratio[k]) and (b<dratio[k+1])):
                fsc=r2[k]+(((r2[k+1]-r2[k])*(b-dratio[k]))/((dratio[k+1]-dratio[k])))
                break
            elif((b>=dratio[k+1]) and (b<dratio[k+2])):
                fsc=r2[k+1]+(((r2[k+2]-r2[k+1])*(b-dratio[k+1]))/((dratio[k+2]-dratio[k+1])))
                break
            elif((b>=dratio[k+2]) and (b<=dratio[k+3])):
                fsc=r2[k+2]+(((r2[k+3]-r2[k+2])*(b-dratio[k+2]))/((dratio[k+3]-dratio[k+2])))
                break     
               # end
    return(fsc)
#fsc=fscvalue(d=300,dc=30,fy=500)
#print(fsc)


def Doubly_Beam(B,d,dc,w,l,fy,fck):
    M=(1.5*w*(l^2)*(1/8))*(10^6);
    M_cap=M/(10^6);
    if (fy==250):
        k=0.53;
        Q=0.36*fck*k*(1-(0.42*k));
    elif (fy==415):
        k=0.48;
        Q=0.36*fck*k*(1-(0.42*k));
    else:
        k=0.46;
        Q=0.36*fck*k*(1-(0.42*k));
    #end
    Mulim=Q*B*d*d;
    Ast1=Mulim/(0.87*fy*d*(1-(0.42*k)));
    Mu2=M-Mulim;
    Ast2=Mu2/(0.87*fy*(d-dc));
    fsc=fscvalue(d,dc,fy);
    Asc=Mu2/((fsc-(0.45*fck))*(d-dc));
    Ast=Ast1+Ast2;
    return(Ast,Asc,M_cap)


def shear_reinf(Ast,b,d,T_load,le,fck,fy):
    pt=(100*Ast)/(b*d);
    #%SW=25*(b*d)*(1/power(10,6));
    #%T_load=LL+DL+SW;
    Max_SF=(T_load*le*(10^3))/2;
    Vu=1.5*Max_SF;
    #%Tu=Vu/(b*d);
    be=(0.8*fck)/(6.89*pt);
    Tc=(0.85*(m.sqrt(0.8*fck))*(m.sqrt(1+(5*be))-1))/(6*be);
    Vc=Tc*b*d;
    Tcu=0.83*m.sqrt(fck);
    Vcu=Tcu*b*d;
    dia=8;#% dia of stirrups
    leg=2;
    Asv=leg*(m.pi/4)*(dia^2);
    msv=(0.87*fy*Asv)/(0.4*b);  #% Minimum Shear reinforcement
    #print(msv)
    if (Vu<=Vc):
        Sv=msv
    elif ((Vu>Vc) and (Vu<Vcu)):
        Vsu=Vu-Vc
        Svv= (Asv*0.87*fy*d)/Vsu
        Svs=min(msv,Svv)
        Sv=min(Svs,300)
    elif(Vu>Vcu):
        Sv='Fail in Shear'
    return(Sv,dia,leg,Vu)
    
#Sv,dia,leg,Vu=shear_reinf(Ast,b,d,T_load,le,fck,fy)

le=int(input('enter the length of the beam in m'))
fck=int(input('enter the characteristic strength of concrete'))
fy=int(input('enter the yield strength of beam'))
DL=float(input('enter the dead load on the beam in kN/m'))
LL=float(input('enter the live load on the beam in kN/m'))
DC=float(input('enter the check depth of the beam in mm'))
CC=float(input('enter the clear cover of the beam in mm'))
dia_bar=int(input('enter the dia of the bar'))

area_bar=0.25*m.pi*m.pow(dia_bar,2);
dbr=2;       #%   Taking depth width ratio
D=((le*1000)/20);    # % finding Depth of beam based on depth beam ratio
Deff=D-CC;
B=Deff/dbr;           # % finding width of beam
if (fy==250):
    k=0.53;
    Q=0.36*fck*k*(1-(0.42*k));
elif (fy==415):
    k=0.48;
    Q=0.36*fck*k*(1-(0.42*k));
else:
    k=0.46;
    Q=0.36*fck*k*(1-(0.42*k));
#end

#%% finding the dimensions of beam
#while True:
SW=25*(B*D)*(1/m.pow(10,6))  # Self weight of Beam
w=LL+DL+SW          #Total load present on the beam
bm=(w*le*le)/8   # Finding the moment genearated due to loads
fbm=1.5*bm;     #% Factoring the moment
x=(fbm*(10e6))/(4*Q)    #% Finding the width required
b=m.pow(x,(1/3));            
d=dbr*b;
if (d<Deff):         #% Checking that provided depth is sufficient or not
    print('')
   # break
else:
    D=D+100;     #% if not increasing the depth
    Deff=D-CC;
    B=Deff/dbr;     #% calculating width again
    #continue

if (d<DC):
    Type='Singly Reinforced Beam';
    SW=25*(B*D)*(1/pow(10,6));
    w=LL+DL+SW;
    bm=(w*le*le)/8; 
    fbm=1.5*bm; 
    Ast=(fbm*(10e6))/(0.87*fy*d*(1-(0.42*k)));     #% finding the Area of steel required
    minimum_Ast=(0.85*b*d)/fy;
    M_capacity=fbm;
    if (Ast<minimum_Ast):
       Ast=minimum_Ast;
       M_capacity=(0.87*fy*d*(1-(0.42*k)))*Ast;
    elif (Ast>(0.04*b*(d+CC))):
        Ast='Redesign';
        M_capacity='Redesign'
    #end
    Asc=0
    total=Ast+Asc
    if float(Ast):
        Sv,dia,leg,Vu=shear_reinf(Ast,b,d,w,le,fck,fy)
    #end
    if float(Sv):#Sv.isnumeric():
        V_capacity=Vu
        Shear='Safe in Shear'
        nbt=np.ceil(Ast/area_bar)
        nbc=2
        lee=le*1000
        #Beam_3DPlotting(lee,b,d,nbt,nbc,Sv,CC)
    else:
        Shear='Unsafe in Shear'
        V_capacity='Redesign'
    #end
 
else:
    Type='Doubly Reinforced Beam';
    d=DC-CC
    b=DC/dbr 
    SW=25*(b*DC)*(1/pow(10,6))
    w=LL+DL+SW
    Ast,Asc,M_capacity=Doubly_Beam(b,d,CC,w,le,fy,fck)
    total=Ast+Asc
    nbt=np.ceil(Ast/area_bar)
    nbc=np.ceil(Asc/area_bar)
    Sv,dia,leg,Vu=shear_reinf(Ast,b,d,w,le,fck,fy)
    #print(Sv)
    if float(Sv):#Sv.replace('.','',1).isdigit():#Sv.isnumeric():
        V_capacity=Vu
        Shear='Safe in shear'
        lee=le*1000;
        #Beam_3DPlotting(le,b,d,nbt,nbc,Sv,CC)
    else:
        Shear='Unsafe in Shear'
        V_capacity='Redesign'
    #end
#end
print(Type)
print(Ast);print(Sv);print(lee)