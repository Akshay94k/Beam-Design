import math as m
import numpy as np
import shear_rein as sr
import d_a as da
'''
le=int(input('enter the length of the beam in m'))
fck=int(input('enter the characteristic strength of concrete'))
fy=int(input('enter the yield strength of beam'))
DL=float(input('enter the dead load on the beam in kN/m'))
LL=float(input('enter the live load on the beam in kN/m'))
DC=float(input('enter the check depth of the beam in mm'))
CC=float(input('enter the clear cover of the beam in mm'))
dia_bar=int(input('enter the dia of the bar'))
'''
def beam(le,fck,fy,DL,LL,DC,CC,dia_bar):
    area_bar=0.25*m.pi*m.pow(dia_bar,2);
    dbr=2;       #%   Taking depth width ratio
    D=((le*1000)/20);    # % finding Depth of beam based on depth beam ratio
    Deff=D-CC;
    B=Deff/dbr;           # % finding width of beam
    if (fy==250):
        k=0.53;
        Q=0.36*fck*k*(1-(0.42*k));
    elif (fy==415):
        k=0.48;
        Q=0.36*fck*k*(1-(0.42*k));
    else:
        k=0.46;
        Q=0.36*fck*k*(1-(0.42*k));
        #end
                
                #%% finding the dimensions of beam
                #while True:
    SW=25*(B*D)*(1/m.pow(10,6))  # Self weight of Beamw=LL+DL+SW          #Total load present on the beam
    w=LL+DL+SW 
    bm=(w*le*le)/8   # Finding the moment genearated due to loads
    fbm=1.5*bm;     #% Factoring the moment
    x=(fbm*(10e6))/(4*Q)    #% Finding the width required
    b=m.pow(x,(1/3));            
    d=dbr*b;
    if (d<Deff):         #% Checking that provided depth is sufficient or not
        print('')
        # break
    else:
        D=D+100;     #% if not increasing the depth
        Deff=D-CC;
        B=Deff/dbr;     #% calculating width again
    #continue
    if (d<DC):
        Type='Singly Reinforced Beam';
        SW=25*(B*D)*(1/pow(10,6));
        w=LL+DL+SW;
        bm=(w*le*le)/8; 
        fbm=1.5*bm; 
        Ast=(fbm*(10e6))/(0.87*fy*d*(1-(0.42*k)));     #% finding the Area of steel required
        minimum_Ast=(0.85*b*d)/fy;
        M_capacity=fbm;
        if (Ast<minimum_Ast):
            Ast=minimum_Ast;
            M_capacity=(0.87*fy*d*(1-(0.42*k)))*Ast;
        elif (Ast>(0.04*b*(d+CC))):
            Ast='Redesign';
            M_capacity='Redesign'
    #end
        Asc=0
        total=Ast+Asc
        if float(Ast):
            Sv,dia,leg,Vu=sr.shear_reinf(Ast,b,d,w,le,fck,fy)
    #end
        if float(Sv):#Sv.isnumeric():
            V_capacity=Vu
            Shear='Safe in Shear'
            nbt=np.ceil(Ast/area_bar)
            nbc=2
            lee=le*1000
        #Beam_3DPlotting(lee,b,d,nbt,nbc,Sv,CC)
        else:
            Shear='Unsafe in Shear'
            V_capacity='Redesign'
    #end
 
    else:
        Type='Doubly Reinforced Beam';
        d=DC-CC
        b=DC/dbr 
        SW=25*(b*DC)*(1/pow(10,6))
        w=LL+DL+SW
        Ast,Asc,M_capacity=da.Doubly_Beam(b,d,CC,w,le,fy,fck)
        total=Ast+Asc
        nbt=np.ceil(Ast/area_bar)
        nbc=np.ceil(Asc/area_bar)
        Sv,dia,leg,Vu=sr.shear_reinf(Ast,b,d,w,le,fck,fy)
        #print(Sv)
        #if Sv == "Fail in shear":
           # Shear="Unsafe in Shear"
        #break
        if float(Sv):
            V_capacity=Vu
            Shear="Safe in shear"
            lee=le*1000;
        #Beam_3DPlotting(le,b,d,nbt,nbc,Sv,CC)
        else:
            Shear="Unsafe in Shear"
            V_capacity="Redesign"
    #end
#end
    #print(Type)
    #print(Ast);print(Sv);print(Shear)   
    return(Type,b,d,Ast,Asc,total,Shear,Sv,nbt,nbc,M_capacity,V_capacity)
Type,b,d,Ast,Asc,total,Shear,Sv,nbt,nbc,M_capacity,V_capacity= beam(le=3,fck=25,fy=415,DL=2,LL=2,DC=500,CC=50,dia_bar=16)