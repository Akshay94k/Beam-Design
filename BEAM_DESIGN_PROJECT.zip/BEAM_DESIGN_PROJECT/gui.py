import tkinter as tk
r = tk.Tk()
r.title('Beam Design')
button = tk.Button(r, text='submit', width=25, command=r.destroy)
button.pack()
r.mainloop()