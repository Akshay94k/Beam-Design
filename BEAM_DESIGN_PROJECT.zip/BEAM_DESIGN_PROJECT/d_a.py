import fscval as fs
def Doubly_Beam(B,d,dc,w,l,fy,fck):
    M=(1.5*w*(l*l)*(1/8))*(10e6);
    M_cap=M/(10e6);
    if (fy==250):
        k=0.53;
        Q=0.36*fck*k*(1-(0.42*k));
    elif (fy==415):
        k=0.48;
        Q=0.36*fck*k*(1-(0.42*k));
    else:
        k=0.46;
        Q=0.36*fck*k*(1-(0.42*k));
    #end
    Mulim=Q*B*d*d;
    Ast1=Mulim/(0.87*fy*d*(1-(0.42*k)));
    Mu2=M-Mulim;
    Ast2=Mu2/(0.87*fy*(d-dc));
    fsc=fs.fscvalue(d,dc,fy);
    Asc=Mu2/((fsc-(0.45*fck))*(d-dc));
    Ast=Ast1+Ast2;
    return(Ast,Asc,M_cap)
#Ast,Asc,M_cap=Doubly_Beam(B,d,dc,w,l,fy,fck)
