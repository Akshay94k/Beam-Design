import math as m
def shear_reinf(Ast,b,d,T_load,le,fck,fy):
    pt=(100*Ast)/(b*d);
    #%SW=25*(b*d)*(1/power(10,6));
    #%T_load=LL+DL+SW;
    Max_SF=(T_load*le*(10e3))/2;
    Vu=1.5*Max_SF;
    #%Tu=Vu/(b*d);
    be=(0.8*fck)/(6.89*pt);
    Tc=(0.85*(m.sqrt(0.8*fck))*(m.sqrt(1+(5*be))-1))/(6*be);
    Vc=Tc*b*d;
    Tcu=0.83*m.sqrt(fck);
    Vcu=Tcu*b*d;
    dia=8;#% dia of stirrups
    leg=2;
    Asv=leg*(m.pi/4)*(dia**2);
    msv=(0.87*fy*Asv)/(0.4*b);  #% Minimum Shear reinforcement

    if (Vu<=Vc):
        Sv=msv
    elif ((Vu>Vc) and (Vu<Vcu)):
        Vsu=Vu-Vc
        Svv= (Asv*0.87*fy*d)/Vsu
        Svs=min(msv,Svv)
        Sv=min(Svs,300)
    elif(Vu>Vcu):
        Sv=90.56#"Fail in Shear"
    #print(Sv)
    return(Sv,dia,leg,Vu)
    
#Sv,dia,leg,Vu=shear_reinf(Ast,b,d,T_load,le,fck,fy)